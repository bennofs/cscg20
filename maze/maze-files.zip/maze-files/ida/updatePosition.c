void __fastcall ServerManager_UpdateServerPosition(ServerManager *a1, __int64 a2, void *a3, int a4, int a5, int a6)
{
  ServerManager *v6; // r15
  _DWORD *v7; // r12
  char *v8; // r13
  char *v9; // r8
  char *v10; // rcx
  _QWORD *v11; // rbx
  float *v12; // rsi
  __int64 **v13; // rbp
  char *v14; // r9
  _QWORD *v15; // r14
  float *v16; // rdx
  __m128 v17; // xmm1
  __m128 v18; // xmm0
  __m128 v19; // xmm2
  __m128 v20; // xmm3
  __m128 v21; // ST00_16
  __m128 v22; // xmm2
  float v23; // xmm1_4
  __m128 v24; // xmm2
  __m128 v25; // xmm2
  float v26; // xmm0_4
  float v27; // xmm0_4
  __m128 v28; // xmm1
  __m128 v29; // xmm0
  __m128 v30; // xmm2
  __m128 v31; // xmm3
  __m128 v32; // ST10_16
  __m128 v33; // xmm2
  float v34; // xmm1_4
  __m128 v35; // xmm2
  __m128 v36; // xmm2
  float v37; // xmm0_4
  float v38; // xmm0_4
  float v39; // xmm2_4
  float v40; // xmm3_4
  float v41; // xmm0_4
  float v42; // xmm4_4
  float v43; // xmm1_4
  float v44; // ST60_4
  __m128 v45; // xmm4
  float v46; // xmm0_4
  __m128 v47; // xmm4
  int v48; // ecx
  float *v49; // rbx
  __int64 *v50; // rax
  int v51; // ecx
  float *v52; // rbp
  __int64 v53; // rdi
  signed __int64 v54; // rsi
  byte_array *buf; // rax
  byte_array *msg; // r14
  float v57; // xmm2_4
  float v58; // ST00_4
  float v59; // xmm2_4
  __int64 v60; // rdi
  unsigned __int64 v61; // rax
  void *v62; // rdx
  __int64 *v63; // rax
  unsigned __int64 v64; // rax
  void *v65; // rdx
  __int64 *v66; // rax
  unsigned __int64 v67; // rax
  void *v68; // rdx
  __int64 *v69; // rax
  unsigned __int64 v70; // rax
  void *v71; // rdx
  __int64 *v72; // rax
  unsigned __int64 v73; // rax
  void *v74; // rdx
  __int64 *v75; // rax
  unsigned __int64 v76; // rax
  void *v77; // rdx
  __int64 *v78; // rax
  unsigned __int64 v79; // rax
  __int64 *v80; // rax
  void *v81; // rdx
  __int16 v82; // bp
  unsigned __int64 v83; // rax
  void *v84; // rdx
  unsigned __int64 v85; // rbx
  __int16 v86; // bp
  unsigned __int64 v87; // rax
  unsigned int v88; // ecx
  __int64 v89; // rax
  float v90; // [rsp+0h] [rbp-A8h]
  float v91; // [rsp+0h] [rbp-A8h]
  float v92; // [rsp+0h] [rbp-A8h]
  float v93; // [rsp+0h] [rbp-A8h]
  float v94; // [rsp+0h] [rbp-A8h]
  float v95; // [rsp+0h] [rbp-A8h]
  float v96; // [rsp+0h] [rbp-A8h]

  v6 = a1;
  if ( !byte_1135A51 )
  {
    sub_322830(0x2462u, a2, a3);
    byte_1135A51 = 1;
  }
  if ( !a1->blocking_position_updates && a1->loggedIn )
  {
    if ( (_BYTE)a2 )
    {
      v7 = (_DWORD *)&a1->time;
      v8 = a1->lastUpdate;
      v9 = a1->current_position;
      v10 = &a1->current_position[8];
      v11 = a1->position;
      v12 = (float *)&a1->position[2];
      v13 = (__int64 **)a1->current_eulerAngles;
      v14 = &a1->current_eulerAngles[8];
      v15 = a1->eulerAngles;
      v16 = (float *)&a1->eulerAngles[2];
      goto LABEL_37;
    }
    v17 = (__m128)*(unsigned __int64 *)a1->current_position;
    v18 = (__m128)(unsigned int)a1->position[2];
    v19 = (__m128)*(unsigned int *)&a1->current_position[8];
    v20 = (__m128)*(unsigned __int64 *)a1->position;
    if ( *(_BYTE *)(*(_QWORD *)&Vector3_TypeInfo + 303LL) & 2 && !*(_DWORD *)(*(_QWORD *)&Vector3_TypeInfo + 224LL) )
    {
      v21 = (__m128)*(unsigned __int64 *)a1->current_position;
      il2cpp_runtime_class_init_0(*(__int64 *)&Vector3_TypeInfo);
      v17 = v21;
    }
    if ( !byte_1137597 )
    {
      sub_322830(0x2E87u, a2, a3);
      byte_1137597 = 1;
    }
    v22 = _mm_unpacklo_ps(v19, v17);
    v23 = COERCE_FLOAT(_mm_shuffle_ps(v17, v17, 229)) - COERCE_FLOAT(_mm_shuffle_ps(v20, v20, 229));
    v24 = _mm_sub_ps(v22, _mm_unpacklo_ps(v18, v20));
    if ( *(_BYTE *)(*(_QWORD *)&Math_TypeInfo + 303LL) & 2 && !*(_DWORD *)(*(_QWORD *)&Math_TypeInfo + 224LL) )
      il2cpp_runtime_class_init_0(*(__int64 *)&Math_TypeInfo);
    v25 = _mm_mul_ps(v24, v24);
    v26 = (float)(COERCE_FLOAT(_mm_shuffle_ps(v25, v25, 229)) + (float)(v23 * v23)) + v25.m128_f32[0];
    if ( v26 < 0.0 )
      v27 = sqrtf(v26);
    else
      v27 = fsqrt(v26);
    v90 = v27;
    v28 = (__m128)*(unsigned __int64 *)a1->current_eulerAngles;
    v29 = (__m128)(unsigned int)a1->eulerAngles[2];
    v30 = (__m128)*(unsigned int *)&a1->current_eulerAngles[8];
    v31 = (__m128)*(unsigned __int64 *)a1->eulerAngles;
    if ( *(_BYTE *)(*(_QWORD *)&Vector3_TypeInfo + 303LL) & 2 && !*(_DWORD *)(*(_QWORD *)&Vector3_TypeInfo + 224LL) )
    {
      v32 = (__m128)*(unsigned __int64 *)a1->current_eulerAngles;
      il2cpp_runtime_class_init_0(*(__int64 *)&Vector3_TypeInfo);
      v28 = v32;
    }
    if ( !byte_1137597 )
    {
      sub_322830(0x2E87u, a2, a3);
      byte_1137597 = 1;
    }
    v33 = _mm_unpacklo_ps(v30, v28);
    v34 = COERCE_FLOAT(_mm_shuffle_ps(v28, v28, 229)) - COERCE_FLOAT(_mm_shuffle_ps(v31, v31, 229));
    v35 = _mm_sub_ps(v33, _mm_unpacklo_ps(v29, v31));
    if ( *(_BYTE *)(*(_QWORD *)&Math_TypeInfo + 303LL) & 2 && !*(_DWORD *)(*(_QWORD *)&Math_TypeInfo + 224LL) )
      il2cpp_runtime_class_init_0(*(__int64 *)&Math_TypeInfo);
    v36 = _mm_mul_ps(v35, v35);
    v37 = (float)(COERCE_FLOAT(_mm_shuffle_ps(v36, v36, 229)) + (float)(v34 * v34)) + v36.m128_f32[0];
    if ( v37 < 0.0 )
      v38 = sqrtf(v37);
    else
      v38 = fsqrt(v37);
    v9 = a1->current_position;
    v10 = &a1->current_position[8];
    v11 = a1->position;
    v12 = (float *)&a1->position[2];
    v13 = (__int64 **)a1->current_eulerAngles;
    v14 = &a1->current_eulerAngles[8];
    v15 = a1->eulerAngles;
    v16 = (float *)&a1->eulerAngles[2];
    v7 = (_DWORD *)&a1->time;
    v8 = a1->lastUpdate;
    v39 = a1->time;
    v40 = *(float *)a1->lastUpdate;
    if ( v90 <= 0.001 && v38 <= 0.1 )
    {
      if ( (float)(v40 + 5.0) > v39 )
        return;
LABEL_37:
      *(_DWORD *)v8 = *v7;
      v48 = *(_DWORD *)v10;
      *v11 = *(_QWORD *)v9;
      v49 = v12;
      *(_DWORD *)v12 = v48;
      v50 = *v13;
      v51 = *(_DWORD *)v14;
      *v15 = *v13;
      v52 = v16;
      *(_DWORD *)v16 = v51;
      v53 = Byte___TypeInfo;
      v54 = 46LL;
      buf = (byte_array *)il2cpp_array_new_specific_0(v50, Byte___TypeInfo, 46LL);
      msg = buf;
      if ( buf )
      {
        if ( !LODWORD(buf->size) )
          goto LABEL_87;
        buf->data[0] = 0x50;
        Buffer_BlockCopy(*(_QWORD *)v6->usersecret, 0LL, buf, 1LL, 8LL);
        v57 = v6->time;
        if ( *(_BYTE *)(*(_QWORD *)&BitConverter_TypeInfo + 303LL) & 2
          && !*(_DWORD *)(*(_QWORD *)&BitConverter_TypeInfo + 224LL) )
        {
          v58 = v6->time;
          il2cpp_runtime_class_init_0(*(__int64 *)&BitConverter_TypeInfo);
          v57 = v58;
        }
        v59 = v57 * 10000.0;
        v60 = (unsigned int)(signed int)v59;
        if ( v59 >= 9.223372e18 )
          v60 = (unsigned int)(signed int)(float)(v59 - 9.223372e18) ^ 0x8000000000000000LL;
        v61 = BitConverter_GetBytes_6071872(v60);
        v63 = (__int64 *)Buffer_BlockCopy(v61, 0LL, msg, 9LL, 8LL);
        v91 = 10000.0 * *(float *)v6->position;
        LOBYTE(v63) = byte_11367E5;
        if ( !byte_11367E5 )
        {
          v63 = (__int64 *)sub_322830(0x8CDu, 0LL, v62);
          byte_11367E5 = 1;
        }
        v53 = Byte___TypeInfo;
        v54 = 4LL;
        v64 = il2cpp_array_new_specific_0(v63, Byte___TypeInfo, 4LL);
        if ( v64 )
        {
          if ( !*(_DWORD *)(v64 + 24) )
            goto LABEL_87;
          *(_DWORD *)(v64 + 32) = (signed int)v91;
          v66 = (__int64 *)Buffer_BlockCopy(v64, 0LL, msg, 17LL, 4LL);
          v92 = *(float *)&v6->position[1];
          LOBYTE(v66) = byte_11367E5;
          if ( !byte_11367E5 )
          {
            v66 = (__int64 *)sub_322830(0x8CDu, 0LL, v65);
            byte_11367E5 = 1;
          }
          v53 = Byte___TypeInfo;
          v54 = 4LL;
          v67 = il2cpp_array_new_specific_0(v66, Byte___TypeInfo, 4LL);
          if ( v67 )
          {
            if ( !*(_DWORD *)(v67 + 24) )
              goto LABEL_87;
            *(_DWORD *)(v67 + 32) = (signed int)(float)(v92 * 10000.0);
            v69 = (__int64 *)Buffer_BlockCopy(v67, 0LL, msg, 21LL, 4LL);
            v93 = *v49;
            LOBYTE(v69) = byte_11367E5;
            if ( !byte_11367E5 )
            {
              v69 = (__int64 *)sub_322830(0x8CDu, 0LL, v68);
              byte_11367E5 = 1;
            }
            v53 = Byte___TypeInfo;
            v54 = 4LL;
            v70 = il2cpp_array_new_specific_0(v69, Byte___TypeInfo, 4LL);
            if ( v70 )
            {
              if ( !*(_DWORD *)(v70 + 24) )
                goto LABEL_87;
              *(_DWORD *)(v70 + 32) = (signed int)(float)(v93 * 10000.0);
              v72 = (__int64 *)Buffer_BlockCopy(v70, 0LL, msg, 25LL, 4LL);
              v94 = *(float *)v6->eulerAngles;
              LOBYTE(v72) = byte_11367E5;
              if ( !byte_11367E5 )
              {
                v72 = (__int64 *)sub_322830(0x8CDu, 0LL, v71);
                byte_11367E5 = 1;
              }
              v53 = Byte___TypeInfo;
              v54 = 4LL;
              v73 = il2cpp_array_new_specific_0(v72, Byte___TypeInfo, 4LL);
              if ( v73 )
              {
                if ( !*(_DWORD *)(v73 + 24) )
                  goto LABEL_87;
                *(_DWORD *)(v73 + 32) = (signed int)(float)(v94 * 10000.0);
                v75 = (__int64 *)Buffer_BlockCopy(v73, 0LL, msg, 29LL, 4LL);
                v95 = *(float *)&v6->eulerAngles[1];
                LOBYTE(v75) = byte_11367E5;
                if ( !byte_11367E5 )
                {
                  v75 = (__int64 *)sub_322830(0x8CDu, 0LL, v74);
                  byte_11367E5 = 1;
                }
                v53 = Byte___TypeInfo;
                v54 = 4LL;
                v76 = il2cpp_array_new_specific_0(v75, Byte___TypeInfo, 4LL);
                if ( v76 )
                {
                  if ( !*(_DWORD *)(v76 + 24) )
                    goto LABEL_87;
                  *(_DWORD *)(v76 + 32) = (signed int)(float)(v95 * 10000.0);
                  v78 = (__int64 *)Buffer_BlockCopy(v76, 0LL, msg, 33LL, 4LL);
                  v96 = *v52;
                  LOBYTE(v78) = byte_11367E5;
                  if ( !byte_11367E5 )
                  {
                    v78 = (__int64 *)sub_322830(0x8CDu, 0LL, v77);
                    byte_11367E5 = 1;
                  }
                  v53 = Byte___TypeInfo;
                  v54 = 4LL;
                  v79 = il2cpp_array_new_specific_0(v78, Byte___TypeInfo, 4LL);
                  if ( v79 )
                  {
                    if ( !*(_DWORD *)(v79 + 24) )
                      goto LABEL_87;
                    *(_DWORD *)(v79 + 32) = (signed int)(float)(v96 * 10000.0);
                    v54 = 0LL;
                    v53 = v79;
                    v80 = (__int64 *)Buffer_BlockCopy(v79, 0LL, msg, 37LL, 4LL);
                    if ( LODWORD(msg->size) <= 0x29 )
                      goto LABEL_87;
                    msg->data[41] = v6->trigger[0];
                    v82 = *(_WORD *)v6->groundedblend;
                    LOBYTE(v80) = byte_11367E4;
                    if ( !byte_11367E4 )
                    {
                      v80 = (__int64 *)sub_322830(0x8CAu, 0LL, v81);
                      byte_11367E4 = 1;
                    }
                    v53 = Byte___TypeInfo;
                    v54 = 2LL;
                    v83 = il2cpp_array_new_specific_0(v80, Byte___TypeInfo, 2LL);
                    v85 = v83;
                    if ( v83 )
                    {
                      if ( !*(_DWORD *)(v83 + 24) )
                        goto LABEL_87;
                      *(_WORD *)(v83 + 32) = v82;
                      v86 = *(_WORD *)v6->notgroundedblend;
                      LOBYTE(v83) = byte_11367E4;
                      if ( !byte_11367E4 )
                      {
                        v83 = sub_322830(0x8CAu, 2LL, v84);
                        byte_11367E4 = 1;
                      }
                      v53 = Byte___TypeInfo;
                      v54 = 2LL;
                      v87 = il2cpp_array_new_specific_0((__int64 *)v83, Byte___TypeInfo, 2LL);
                      if ( v87 )
                      {
                        if ( *(_DWORD *)(v87 + 24) )
                        {
                          *(_WORD *)(v87 + 32) = v86;
                          if ( *(_DWORD *)(v85 + 24) )
                          {
                            v88 = msg->size;
                            if ( v88 > 0x2A )
                            {
                              msg->data[42] = *(_BYTE *)(v85 + 32);
                              if ( *(_DWORD *)(v85 + 24) > 1u && v88 > 0x2B )
                              {
                                msg->data[43] = *(_BYTE *)(v85 + 33);
                                if ( *(_DWORD *)(v87 + 24) )
                                {
                                  if ( v88 > 0x2C )
                                  {
                                    msg->data[44] = *(_BYTE *)(v87 + 32);
                                    if ( *(_DWORD *)(v87 + 24) > 1u && v88 > 0x2D )
                                    {
                                      msg->data[45] = *(_BYTE *)(v87 + 33);
                                      v6->trigger[0] = 0;
                                      ServerManager_sendData(v6, (__int64)msg);
                                      return;
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
LABEL_87:
                        v89 = sub_3231D0(v53, v54);
                        sub_322D10(v89, 0LL);
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      throwNpe_0(v53);
    }
    v41 = *(float *)a1->heartbeat_roundtrip;
    v42 = *(float *)a1->rate_limit;
    v43 = *(float *)a1->noPlayerMultiplier;
    if ( *(_BYTE *)(*(_QWORD *)&Mathf_TypeInfo + 303LL) & 2 && !*(_DWORD *)(*(_QWORD *)&Mathf_TypeInfo + 224LL) )
    {
      v44 = *(float *)a1->rate_limit;
      il2cpp_runtime_class_init_0(*(__int64 *)&Mathf_TypeInfo);
      v42 = v44;
      v14 = &a1->current_eulerAngles[8];
      v10 = &a1->current_position[8];
      v9 = a1->current_position;
      v12 = (float *)&a1->position[2];
      v16 = (float *)&a1->eulerAngles[2];
    }
    v45.m128_f32[0] = v42 + (float)(v41 * v43);
    v46 = fminf(1.0, v45.m128_f32[0]);
    v47 = _mm_cmpge_ss(v45, (__m128)0x3D4CCCCDu);
    if ( (float)(v40
               + COERCE_FLOAT(*(unsigned __int128 *)&_mm_andnot_ps(v47, (__m128)0x3D4CCCCDu) | LODWORD(v46) & v47.m128_i32[0])) <= v39 )
      goto LABEL_37;
  }
}
